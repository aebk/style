import { useState, useRef, useEffect, useCallback } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface SkinConfig {
  x: number;
  y: number;
  width: number;
  src: string | null;
}

interface Settings {
  frontSkin: SkinConfig;
  backSkin: SkinConfig;
  avatarSrc: string | null;
  color1: string;
  color2: string;
  postText: string;
}

// ─── Defaults ─────────────────────────────────────────────────────────────────

const DEFAULT_SETTINGS: Settings = {
  frontSkin: { x: 220, y: 60, width: 180, src: null },
  backSkin: { x: 420, y: 80, width: 160, src: null },
  avatarSrc: null,
  color1: "#6c3fff",
  color2: "#ff6fb4",
  postText: "my new skin just dropped 🔥 what do you think?",
};

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem("skinShowcaseSettings");
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Settings;
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function saveSettings(s: Settings) {
  localStorage.setItem("skinShowcaseSettings", JSON.stringify(s));
}

// ─── Telegram SVG icon ────────────────────────────────────────────────────────

function TelegramIcon({ size = 16 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="12" cy="12" r="12" fill="#29B6F6" />
      <path
        d="M5.5 11.8l2.9 1.1 1.1 3.5c.07.22.34.3.52.16l1.62-1.32 3.14 2.32c.28.2.67.05.73-.29l2.27-10.5c.07-.35-.27-.64-.6-.51L5.4 10.87c-.35.14-.34.63.1.93z"
        fill="white"
      />
    </svg>
  );
}

// ─── Heart icon ───────────────────────────────────────────────────────────────

function HeartIcon({ filled, size = 20 }: { filled: boolean; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "#f91880" : "none"}
      stroke={filled ? "#f91880" : "rgba(255,255,255,0.65)"}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

// ─── Retweet icon ─────────────────────────────────────────────────────────────

function RetweetIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="rgba(255,255,255,0.65)"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="17 1 21 5 17 9" />
      <path d="M3 11V9a4 4 0 0 1 4-4h14" />
      <polyline points="7 23 3 19 7 15" />
      <path d="M21 13v2a4 4 0 0 1-4 4H3" />
    </svg>
  );
}

// ─── Comment icon ─────────────────────────────────────────────────────────────

function CommentIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="rgba(255,255,255,0.65)"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}

// ─── Share icon ───────────────────────────────────────────────────────────────

function ShareIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="rgba(255,255,255,0.65)"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="18" cy="5" r="3" />
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="19" r="3" />
      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
      <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
    </svg>
  );
}

// ─── Views icon ───────────────────────────────────────────────────────────────

function ViewsIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="rgba(255,255,255,0.65)"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

// ─── Bookmark icon ────────────────────────────────────────────────────────────

function BookmarkIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="rgba(255,255,255,0.65)"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
    </svg>
  );
}

// ─── Dots icon ────────────────────────────────────────────────────────────────

function DotsIcon({ size = 18 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="rgba(255,255,255,0.6)"
    >
      <circle cx="5" cy="12" r="2" />
      <circle cx="12" cy="12" r="2" />
      <circle cx="19" cy="12" r="2" />
    </svg>
  );
}

// ─── Settings icon ────────────────────────────────────────────────────────────

function SettingsIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

// ─── Upload icon ──────────────────────────────────────────────────────────────

function UploadIcon({ size = 14 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </svg>
  );
}

// ─── XY Size controls ─────────────────────────────────────────────────────────

function XYSizeControls({
  label,
  cfg,
  onChange,
}: {
  label: string;
  cfg: SkinConfig;
  onChange: (patch: Partial<SkinConfig>) => void;
}) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div className="section-label">{label}</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 }}>
        <div>
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, marginBottom: 3 }}>X</div>
          <input
            type="number"
            className="glass-input"
            value={cfg.x}
            onChange={(e) => onChange({ x: Number(e.target.value) })}
          />
        </div>
        <div>
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, marginBottom: 3 }}>Y</div>
          <input
            type="number"
            className="glass-input"
            value={cfg.y}
            onChange={(e) => onChange({ y: Number(e.target.value) })}
          />
        </div>
        <div>
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, marginBottom: 3 }}>Size</div>
          <input
            type="number"
            className="glass-input"
            value={cfg.width}
            onChange={(e) => onChange({ width: Math.max(20, Number(e.target.value)) })}
          />
        </div>
      </div>
    </div>
  );
}

// ─── Draggable Skin Image ─────────────────────────────────────────────────────

function DraggableSkin({
  cfg,
  onMove,
  screenshotMode,
}: {
  cfg: SkinConfig;
  onMove: (x: number, y: number) => void;
  screenshotMode: boolean;
}) {
  const dragging = useRef(false);
  const startPos = useRef({ mx: 0, my: 0, ox: 0, oy: 0 });

  const onMouseDown = useCallback(
    (e: React.MouseEvent) => {
      if (screenshotMode) return;
      e.preventDefault();
      dragging.current = true;
      startPos.current = { mx: e.clientX, my: e.clientY, ox: cfg.x, oy: cfg.y };
      const handleMove = (me: MouseEvent) => {
        if (!dragging.current) return;
        const dx = me.clientX - startPos.current.mx;
        const dy = me.clientY - startPos.current.my;
        onMove(startPos.current.ox + dx, startPos.current.oy + dy);
      };
      const handleUp = () => {
        dragging.current = false;
        window.removeEventListener("mousemove", handleMove);
        window.removeEventListener("mouseup", handleUp);
      };
      window.addEventListener("mousemove", handleMove);
      window.addEventListener("mouseup", handleUp);
    },
    [cfg.x, cfg.y, onMove, screenshotMode]
  );

  if (!cfg.src) return null;

  return (
    <img
      src={cfg.src}
      alt="skin"
      className="skin-image"
      draggable={false}
      onMouseDown={onMouseDown}
      style={{
        left: cfg.x,
        top: cfg.y,
        width: cfg.width,
        cursor: screenshotMode ? "default" : "move",
        zIndex: 10,
      }}
    />
  );
}

// ─── Settings Modal ───────────────────────────────────────────────────────────

function SettingsModal({
  settings,
  onChange,
  onClose,
  onSave,
  screenshotMode,
  onScreenshotToggle,
}: {
  settings: Settings;
  onChange: (patch: Partial<Settings>) => void;
  onClose: () => void;
  onSave: () => void;
  screenshotMode: boolean;
  onScreenshotToggle: () => void;
}) {
  const frontFileRef = useRef<HTMLInputElement>(null);
  const backFileRef = useRef<HTMLInputElement>(null);
  const avatarFileRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    key: "frontSkin" | "backSkin"
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const src = ev.target?.result as string;
      onChange({ [key]: { ...settings[key], src } });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      onChange({ avatarSrc: ev.target?.result as string });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  return (
    <div
      className="settings-overlay"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
      }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="settings-panel"
        style={{
          borderRadius: 20,
          padding: 24,
          width: "100%",
          maxWidth: 420,
          maxHeight: "90vh",
          overflowY: "auto",
          color: "#fff",
          position: "relative",
        }}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 24,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <SettingsIcon size={20} />
            <span style={{ fontWeight: 700, fontSize: 18 }}>Settings</span>
          </div>
          <button
            onClick={onClose}
            style={{
              background: "rgba(255,255,255,0.1)",
              border: "1px solid rgba(255,255,255,0.15)",
              color: "rgba(255,255,255,0.7)",
              borderRadius: 8,
              width: 32,
              height: 32,
              cursor: "pointer",
              fontSize: 18,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            ×
          </button>
        </div>

        {/* Screenshot mode toggle */}
        <div
          style={{
            background: "rgba(255,255,255,0.05)",
            borderRadius: 12,
            padding: "12px 16px",
            marginBottom: 20,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>📸 Screenshot Mode</div>
            <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 11, marginTop: 2 }}>
              Hide all UI elements
            </div>
          </div>
          <div
            className={`toggle-track ${screenshotMode ? "active" : ""}`}
            onClick={onScreenshotToggle}
          >
            <div className="toggle-thumb" />
          </div>
        </div>

        {/* Divider */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", marginBottom: 20 }} />

        {/* Avatar */}
        <div style={{ marginBottom: 20 }}>
          <div className="section-label">Avatar</div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div
              style={{
                width: 48,
                height: 48,
                borderRadius: "50%",
                overflow: "hidden",
                background: "rgba(255,255,255,0.1)",
                border: "2px solid rgba(255,255,255,0.2)",
                flexShrink: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 20,
              }}
            >
              {settings.avatarSrc ? (
                <img
                  src={settings.avatarSrc}
                  alt="avatar"
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              ) : (
                "🎮"
              )}
            </div>
            <div style={{ flex: 1 }}>
              <button className="upload-btn" onClick={() => avatarFileRef.current?.click()}>
                <UploadIcon /> Upload Avatar
              </button>
              {settings.avatarSrc && (
                <button
                  className="upload-btn"
                  style={{ marginTop: 6, borderColor: "rgba(255,80,80,0.3)", color: "rgba(255,100,100,0.8)" }}
                  onClick={() => onChange({ avatarSrc: null })}
                >
                  Remove
                </button>
              )}
              <input
                ref={avatarFileRef}
                type="file"
                accept="image/*"
                style={{ display: "none" }}
                onChange={handleAvatarUpload}
              />
            </div>
          </div>
        </div>

        {/* Divider */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", marginBottom: 20 }} />

        {/* Post text */}
        <div style={{ marginBottom: 20 }}>
          <div className="section-label">Post Text</div>
          <textarea
            className="glass-textarea"
            value={settings.postText}
            onChange={(e) => onChange({ postText: e.target.value })}
            placeholder="What's on your mind?"
            rows={3}
          />
        </div>

        {/* Divider */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", marginBottom: 20 }} />

        {/* Background colors */}
        <div style={{ marginBottom: 20 }}>
          <div className="section-label">Background Gradient</div>
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <div style={{ flex: 1 }}>
              <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, marginBottom: 4 }}>Color 1</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div
                  className="color-swatch"
                  style={{ background: settings.color1 }}
                  onClick={() => document.getElementById("color1input")?.click()}
                />
                <input
                  id="color1input"
                  type="color"
                  value={settings.color1}
                  onChange={(e) => onChange({ color1: e.target.value })}
                  style={{ width: 0, height: 0, opacity: 0, position: "absolute" }}
                />
                <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>{settings.color1}</span>
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, marginBottom: 4 }}>Color 2</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div
                  className="color-swatch"
                  style={{ background: settings.color2 }}
                  onClick={() => document.getElementById("color2input")?.click()}
                />
                <input
                  id="color2input"
                  type="color"
                  value={settings.color2}
                  onChange={(e) => onChange({ color2: e.target.value })}
                  style={{ width: 0, height: 0, opacity: 0, position: "absolute" }}
                />
                <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>{settings.color2}</span>
              </div>
            </div>
          </div>
          {/* Preview gradient strip */}
          <div
            style={{
              marginTop: 10,
              height: 8,
              borderRadius: 4,
              background: `linear-gradient(135deg, ${settings.color1}, ${settings.color2})`,
            }}
          />
        </div>

        {/* Divider */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", marginBottom: 20 }} />

        {/* Front skin */}
        <div style={{ marginBottom: 20 }}>
          <div className="section-label">Front Skin (PNG)</div>
          <div style={{ marginBottom: 8 }}>
            <button className="upload-btn" onClick={() => frontFileRef.current?.click()}>
              <UploadIcon />
              {settings.frontSkin.src ? "Replace Front Skin" : "Upload Front Skin"}
            </button>
            {settings.frontSkin.src && (
              <button
                className="upload-btn"
                style={{ marginTop: 6, borderColor: "rgba(255,80,80,0.3)", color: "rgba(255,100,100,0.8)" }}
                onClick={() => onChange({ frontSkin: { ...settings.frontSkin, src: null } })}
              >
                Remove
              </button>
            )}
            <input
              ref={frontFileRef}
              type="file"
              accept="image/png,image/*"
              style={{ display: "none" }}
              onChange={(e) => handleFileUpload(e, "frontSkin")}
            />
          </div>
          <XYSizeControls
            label="Front Position & Size"
            cfg={settings.frontSkin}
            onChange={(patch) =>
              onChange({ frontSkin: { ...settings.frontSkin, ...patch } })
            }
          />
        </div>

        {/* Divider */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", marginBottom: 20 }} />

        {/* Back skin */}
        <div style={{ marginBottom: 20 }}>
          <div className="section-label">Back Skin (PNG)</div>
          <div style={{ marginBottom: 8 }}>
            <button className="upload-btn" onClick={() => backFileRef.current?.click()}>
              <UploadIcon />
              {settings.backSkin.src ? "Replace Back Skin" : "Upload Back Skin"}
            </button>
            {settings.backSkin.src && (
              <button
                className="upload-btn"
                style={{ marginTop: 6, borderColor: "rgba(255,80,80,0.3)", color: "rgba(255,100,100,0.8)" }}
                onClick={() => onChange({ backSkin: { ...settings.backSkin, src: null } })}
              >
                Remove
              </button>
            )}
            <input
              ref={backFileRef}
              type="file"
              accept="image/png,image/*"
              style={{ display: "none" }}
              onChange={(e) => handleFileUpload(e, "backSkin")}
            />
          </div>
          <XYSizeControls
            label="Back Position & Size"
            cfg={settings.backSkin}
            onChange={(patch) =>
              onChange({ backSkin: { ...settings.backSkin, ...patch } })
            }
          />
        </div>

        {/* Save & Close */}
        <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
          <button
            onClick={() => { onSave(); onClose(); }}
            style={{
              flex: 1,
              background: "linear-gradient(135deg, rgba(99,102,241,0.7), rgba(168,85,247,0.7))",
              border: "1px solid rgba(255,255,255,0.2)",
              color: "#fff",
              borderRadius: 10,
              padding: "10px 0",
              fontWeight: 700,
              fontSize: 14,
              cursor: "pointer",
              transition: "opacity 0.2s",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.85")}
            onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
          >
            💾 Save & Close
          </button>
          <button
            onClick={onClose}
            style={{
              background: "rgba(255,255,255,0.08)",
              border: "1px solid rgba(255,255,255,0.15)",
              color: "rgba(255,255,255,0.6)",
              borderRadius: 10,
              padding: "10px 16px",
              fontWeight: 600,
              fontSize: 14,
              cursor: "pointer",
            }}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Twitter Post Card ────────────────────────────────────────────────────────

function TwitterPost({
  settings,
  onDotsClick,
  screenshotMode,
}: {
  settings: Settings;
  onDotsClick: () => void;
  screenshotMode: boolean;
}) {
  const [liked, setLiked] = useState(false);
  const [heartAnim, setHeartAnim] = useState(false);
  const [likeCount] = useState(69);

  const now = new Date();
  const timeStr = now.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
  const dateStr = now.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  const handleLike = () => {
    setLiked((v) => !v);
    setHeartAnim(true);
    setTimeout(() => setHeartAnim(false), 300);
  };

  return (
    <div
      className="glass-panel glass-shine"
      style={{
        borderRadius: 20,
        padding: "16px 18px",
        width: 520,
        minWidth: 320,
        maxWidth: "95vw",
        position: "relative",
        color: "#fff",
        overflow: "visible",
      }}
    >
      {/* Header row */}
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12, marginBottom: 14 }}>
        {/* Avatar */}
        <div
          style={{
            width: 44,
            height: 44,
            borderRadius: "50%",
            overflow: "hidden",
            flexShrink: 0,
            background: "rgba(255,255,255,0.15)",
            border: "2px solid rgba(255,255,255,0.3)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 22,
          }}
        >
          {settings.avatarSrc ? (
            <img
              src={settings.avatarSrc}
              alt="avatar"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            "🎮"
          )}
        </div>

        {/* Name + username */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div
            style={{
              fontWeight: 800,
              fontSize: 15,
              color: "#fff",
              letterSpacing: "-0.01em",
              lineHeight: 1.2,
            }}
          >
            ∆|reathm|∆
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 4,
              color: "rgba(255,255,255,0.55)",
              fontSize: 13,
              marginTop: 2,
            }}
          >
            <TelegramIcon size={14} />
            <span>@reathm_bunker</span>
          </div>
        </div>

        {/* Dots button */}
        <button
          onClick={onDotsClick}
          title={screenshotMode ? "Back to Settings" : "Options"}
          style={{
            background: "rgba(255,255,255,0.07)",
            border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: 8,
            padding: "4px 8px",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transition: "background 0.2s",
            flexShrink: 0,
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.15)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.07)")}
        >
          <DotsIcon />
        </button>
      </div>

      {/* Post text */}
      <div
        style={{
          fontSize: 15,
          lineHeight: 1.55,
          color: "rgba(255,255,255,0.92)",
          marginBottom: 14,
          wordBreak: "break-word",
          whiteSpace: "pre-wrap",
        }}
      >
        {settings.postText || "my new skin just dropped 🔥"}
      </div>

      {/* Photo grid — 2 slots */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 8,
          marginBottom: 14,
          height: 200,
        }}
      >
        {/* Slot 1 — front skin */}
        <div
          className="photo-slot"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 13,
            color: "rgba(255,255,255,0.3)",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {settings.frontSkin.src ? (
            <img
              src={settings.frontSkin.src}
              alt="front skin"
              style={{
                maxWidth: "100%",
                maxHeight: "100%",
                objectFit: "contain",
                filter: "drop-shadow(0 2px 12px rgba(0,0,0,0.5))",
              }}
              draggable={false}
            />
          ) : (
            <div style={{ textAlign: "center", padding: 16 }}>
              <div style={{ fontSize: 28, marginBottom: 4 }}>🎮</div>
              <div>Front</div>
            </div>
          )}
        </div>

        {/* Slot 2 — back skin */}
        <div
          className="photo-slot"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 13,
            color: "rgba(255,255,255,0.3)",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {settings.backSkin.src ? (
            <img
              src={settings.backSkin.src}
              alt="back skin"
              style={{
                maxWidth: "100%",
                maxHeight: "100%",
                objectFit: "contain",
                filter: "drop-shadow(0 2px 12px rgba(0,0,0,0.5))",
              }}
              draggable={false}
            />
          ) : (
            <div style={{ textAlign: "center", padding: 16 }}>
              <div style={{ fontSize: 28, marginBottom: 4 }}>🔮</div>
              <div>Back</div>
            </div>
          )}
        </div>
      </div>

      {/* Timestamp */}
      <div
        style={{
          color: "rgba(255,255,255,0.4)",
          fontSize: 13,
          marginBottom: 14,
          borderBottom: "1px solid rgba(255,255,255,0.1)",
          paddingBottom: 12,
        }}
      >
        {timeStr} · {dateStr}
      </div>

      {/* Stats row */}
      <div
        style={{
          display: "flex",
          gap: 20,
          color: "rgba(255,255,255,0.55)",
          fontSize: 13,
          marginBottom: 12,
          borderBottom: "1px solid rgba(255,255,255,0.1)",
          paddingBottom: 12,
        }}
      >
        <span>
          <strong style={{ color: "#fff" }}>4</strong> Reposts
        </span>
        <span>
          <strong style={{ color: "#fff" }}>2</strong> Quotes
        </span>
        <span>
          <strong style={{ color: "#fff" }}>{liked ? likeCount + 1 : likeCount}</strong> Likes
        </span>
        <span>
          <strong style={{ color: "#fff" }}>1.2K</strong> Views
        </span>
      </div>

      {/* Action buttons */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-around",
        }}
      >
        <button
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            color: "rgba(255,255,255,0.55)",
            fontSize: 13,
            padding: "6px 8px",
            borderRadius: 8,
            transition: "background 0.15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.07)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
        >
          <CommentIcon size={19} />
          <span>14</span>
        </button>

        <button
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            color: "rgba(255,255,255,0.55)",
            fontSize: 13,
            padding: "6px 8px",
            borderRadius: 8,
            transition: "background 0.15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.07)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
        >
          <RetweetIcon size={19} />
          <span>4</span>
        </button>

        <button
          className={heartAnim ? "heart-pulse" : ""}
          onClick={handleLike}
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            color: liked ? "#f91880" : "rgba(255,255,255,0.55)",
            fontSize: 13,
            padding: "6px 8px",
            borderRadius: 8,
            transition: "background 0.15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(249,24,128,0.1)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
        >
          <HeartIcon filled={liked} size={19} />
          <span>{liked ? likeCount + 1 : likeCount}</span>
        </button>

        <button
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            color: "rgba(255,255,255,0.55)",
            fontSize: 13,
            padding: "6px 8px",
            borderRadius: 8,
            transition: "background 0.15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.07)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
        >
          <ViewsIcon size={19} />
          <span>1.2K</span>
        </button>

        <button
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            color: "rgba(255,255,255,0.55)",
            fontSize: 13,
            padding: "6px 8px",
            borderRadius: 8,
            transition: "background 0.15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.07)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
        >
          <BookmarkIcon size={19} />
        </button>

        <button
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            color: "rgba(255,255,255,0.55)",
            fontSize: 13,
            padding: "6px 8px",
            borderRadius: 8,
            transition: "background 0.15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.07)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
        >
          <ShareIcon size={19} />
        </button>
      </div>
    </div>
  );
}

// ─── Floating skins layer (over background, behind post) ─────────────────────

function FloatingSkins({
  settings,
  onChange,
  screenshotMode,
}: {
  settings: Settings;
  onChange: (patch: Partial<Settings>) => void;
  screenshotMode: boolean;
}) {
  return (
    <>
      <DraggableSkin
        cfg={settings.backSkin}
        onMove={(x, y) => onChange({ backSkin: { ...settings.backSkin, x, y } })}
        screenshotMode={screenshotMode}
      />
      <DraggableSkin
        cfg={settings.frontSkin}
        onMove={(x, y) => onChange({ frontSkin: { ...settings.frontSkin, x, y } })}
        screenshotMode={screenshotMode}
      />
    </>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [showSettings, setShowSettings] = useState(false);
  const [screenshotMode, setScreenshotMode] = useState(false);

  const handleChange = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleSave = useCallback(() => {
    saveSettings(settings);
  }, [settings]);

  // Auto-save on settings change with debounce
  useEffect(() => {
    const t = setTimeout(() => saveSettings(settings), 800);
    return () => clearTimeout(t);
  }, [settings]);

  const handleDotsClick = () => {
    if (screenshotMode) {
      setScreenshotMode(false);
      setShowSettings(true);
    } else {
      setShowSettings(true);
    }
  };

  const bgGradient = `linear-gradient(135deg, ${settings.color1} 0%, ${settings.color2} 100%)`;

  return (
    <div
      className={screenshotMode ? "screenshot-mode" : ""}
      style={{
        width: "100vw",
        height: "100vh",
        background: bgGradient,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Ambient glow blobs */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
          zIndex: 0,
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            width: "60vw",
            height: "60vw",
            borderRadius: "50%",
            background: `radial-gradient(circle, ${settings.color1}55 0%, transparent 70%)`,
            top: "-15vw",
            left: "-10vw",
            filter: "blur(40px)",
          }}
        />
        <div
          style={{
            position: "absolute",
            width: "50vw",
            height: "50vw",
            borderRadius: "50%",
            background: `radial-gradient(circle, ${settings.color2}55 0%, transparent 70%)`,
            bottom: "-10vw",
            right: "-5vw",
            filter: "blur(40px)",
          }}
        />
        <div
          style={{
            position: "absolute",
            width: "30vw",
            height: "30vw",
            borderRadius: "50%",
            background: `radial-gradient(circle, rgba(255,255,255,0.06) 0%, transparent 70%)`,
            top: "30%",
            left: "60%",
            filter: "blur(30px)",
          }}
        />
      </div>

      {/* Floating skins layer (back rendered first so front is on top) */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 2,
          pointerEvents: screenshotMode ? "none" : "auto",
        }}
      >
        <FloatingSkins
          settings={settings}
          onChange={handleChange}
          screenshotMode={screenshotMode}
        />
      </div>

      {/* Post card */}
      <div style={{ position: "relative", zIndex: 5 }}>
        <TwitterPost
          settings={settings}
          onDotsClick={handleDotsClick}
          screenshotMode={screenshotMode}
        />
      </div>

      {/* Settings FAB */}
      <button
        className="ui-hide"
        onClick={() => setShowSettings(true)}
        title="Open Settings"
        style={{
          position: "fixed",
          bottom: 24,
          right: 24,
          zIndex: 100,
          width: 52,
          height: 52,
          borderRadius: "50%",
          background: "rgba(0,0,0,0.35)",
          backdropFilter: "blur(16px)",
          WebkitBackdropFilter: "blur(16px)",
          border: "1px solid rgba(255,255,255,0.2)",
          color: "rgba(255,255,255,0.85)",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 4px 20px rgba(0,0,0,0.3)",
          transition: "transform 0.2s, background 0.2s",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.1)")}
        onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
      >
        <SettingsIcon size={22} />
      </button>

      {/* Settings modal */}
      {showSettings && (
        <SettingsModal
          settings={settings}
          onChange={handleChange}
          onClose={() => setShowSettings(false)}
          onSave={handleSave}
          screenshotMode={screenshotMode}
          onScreenshotToggle={() => {
            setScreenshotMode((v) => !v);
            if (!screenshotMode) setShowSettings(false);
          }}
        />
      )}
    </div>
  );
}
